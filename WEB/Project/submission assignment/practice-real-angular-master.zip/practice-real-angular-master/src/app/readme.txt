In angular every component will have three files
1. html
2. CSS
3. typescript (just like JavaScript but can have types of variables.. etc...)
