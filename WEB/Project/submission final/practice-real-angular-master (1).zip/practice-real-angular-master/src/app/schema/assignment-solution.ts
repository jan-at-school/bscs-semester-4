export interface AssignmentSolution {
   id: number;

   text: string;
   userId:number;
   externalAttachment:number;
   jsonData:string;
   likes:number;
   dislikes:number;
   time:number;


      dpImgUrl:any;
      username:any;
 }
