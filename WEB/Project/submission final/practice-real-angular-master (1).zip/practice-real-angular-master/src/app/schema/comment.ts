export interface Comment {
   id: number;
   username: string;
   assignmentId: number;
   text: string;
   userId:number;
   dpImgUrl:string;

 }

// {"id":"1","username":"jan.arifullah","password":"abc","email":"jan.arifullah@gmail.com","score":"0","jsonData":"","about":""}
