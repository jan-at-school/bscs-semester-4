export interface User {
   id: number;
   username: string;
   email: string;
   password: string;
   score: string;
   jsonData:string;
   about:string;
   dpImgUrl:string;
   points:string;
 }

// {"id":"1","username":"jan.arifullah","password":"abc","email":"jan.arifullah@gmail.com","score":"0","jsonData":"","about":""}
