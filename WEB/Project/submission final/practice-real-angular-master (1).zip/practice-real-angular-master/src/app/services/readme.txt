Services will have the code related to communication with server.
