<?php

namespace Cloudinary\Api;

/**
 * Class Error
 * @package Cloudinary\Api
 */
class Error extends \Exception
{
}
