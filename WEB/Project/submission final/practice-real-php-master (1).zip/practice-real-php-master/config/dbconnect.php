<?php
$databaseHost = '182.50.133.91:3306';
$databaseName = 'practicereal';
$databaseUsername = 'pr_dbuser';
$databasePassword = 'eI1ys!22';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);


?>
