<?php

    // include_once("authenticate.php");


include_once(".\global\utility.php");

  // //now we turn our encrypted data back to plain text
  // $password_decrypted = my_decrypt("eGNxYlNHamhGK09yZWE3c0VVY1ZsNDNQVHNrREl1Q0lSRG9Ld3BhcTk0SEl4Yk80V09xZlBvQlBLQnFSYlcvSVVBOVN1WXNBbUpnLzc4aUlwaUtCSkE3UXd4M0QvTjc4cGJWcDhybTFoSkk9OjpYNO0RqR0B2f7yING5Hkuw", $key);
  // echo $password_decrypted . "<br>";



  echo base64_encode('[
{
"url":"sdlkafjadsl",
"type":"type"
},
{
"url":"sdlkafjadsl",
"type":"type"
},

{
"url":"sdlkafjadsl",
"type":"type"
}


}}');

 ?>
